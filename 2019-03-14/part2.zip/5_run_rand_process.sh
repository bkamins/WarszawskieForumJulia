#!/bin/bash

julia -p $(nproc) 5_rand_process.jl

